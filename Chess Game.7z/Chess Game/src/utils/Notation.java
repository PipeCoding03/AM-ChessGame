package utils;

public class Notation {
    public static boolean isUpperCase(String piece){
        return piece.equals(piece.toUpperCase());
    }
}