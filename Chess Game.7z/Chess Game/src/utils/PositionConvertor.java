package utils;

import main.Main;

public class PositionConvertor {
    private static int index;
    private static int x;
    private static int y;
    
    public static int fromIndexToCoords(int index, String axis, String type){
        index++;
        
        if (index % 8 == 0){
            x = 8;
        } else {
            x = index % 8;
        }

        if (index % 8 == 0){
            y = index / 8;
        } else {
            y = (index / 8) + 1;
        }
        
        switch (axis){
            case "x":
                x--;
                
                if (type.equals("squares")){
                    
                } else if (type.equals("pixels")){
                    x *= Main.SQUARE_SIDE;
                }
                
                return x;
            case "y":
                y--;
                
                if (type.equals("squares")){
                    
                } else if (type.equals("pixels")){
                    y *= Main.SQUARE_SIDE;
                }
                
                return y;
            default:
                return -1;
        }
    }
    
    public static int fromCoordsToIndex(int x, int y){
        x /= Main.SQUARE_SIDE;
        y /= Main.SQUARE_SIDE;
        index = (y * 8) + x;
        
        return index;
    }
    
    public static String fromIndexToNotation(int position){
        String[] columns = {"a", "b", "c", "d", "e", "f", "g", "h"};
        int[] rows = {8, 7, 6, 5, 4, 3, 2, 1};
        
        return columns[fromIndexToCoords(position, "x", "squares")] + rows[fromIndexToCoords(position, "y", "squares")];
    }
    
    public static String fromCoordsToNotation(int x, int y){
        String[] columns = {"a", "b", "c", "d", "e", "f", "g", "h"};
        int[] rows = {8, 7, 6, 5, 4, 3, 2, 1};
        
        return columns[x] + rows[y];
    }
    
    public static int fromNotationToCoords(String notation, String axis){
        int x = 2, y = 0;
        
        if (axis.equals("x")){
            String[] columns = {"a", "b", "c", "d", "e", "f", "g", "h"};
            
            for (int i = 0; i < columns.length; i++){
                if (String.valueOf(notation.charAt(0)).equals(columns[i])){
                    x = i;
                }
            }
            
            return x;
        } else {
            int[] rows = {8, 7, 6, 5, 4, 3, 2, 1};
            
            for (int i = 0; i < rows.length; i++){
                if (Integer.parseInt(String.valueOf(notation.charAt(1))) == rows[i]){
                    y = i;
                }
            }
            
            return y;
        }
    }
    
    public static void main(String[] args) {
        System.out.println(fromNotationToCoords("c7", "x"));
        System.out.println(fromNotationToCoords("c7", "y"));
    }
}