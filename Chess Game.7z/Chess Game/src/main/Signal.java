package main;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Signal extends JLabel {
    private ImageIcon signal;
    
    public void setSignal(ImageIcon signal){
        this.signal = signal;
        
        setIcon(new ImageIcon(signal.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH)));
    }
    
    public ImageIcon getSignal(){
        return signal;
    }
}