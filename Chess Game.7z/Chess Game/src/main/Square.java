//package main;
//
//import java.awt.Image;
//import javax.swing.ImageIcon;
//import javax.swing.JLabel;
//
//public class Square extends JLabel {
//    private int index;
//    private Piece piece = new Piece();
//    
//    public Square(){
//        setIcon(new ImageIcon(piece.getIcon().getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH)));
//    }
//    
//    public void setPiece(Piece piece, int index){
//        this.piece = piece;
//        piece.setPosition(index);
//        
//        setIcon(new ImageIcon(piece.getIcon().getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH)));
//        
////        piece.setX(x);
////        piece.setY(y);
//    }
//    
////    public void setSignal(ImageIcon signal){
////        this.signal = signal;
////        setIcon(new ImageIcon(signal.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH)));
////    }
////    
////    public ImageIcon getSignal(){
////        return signal;
////    }
//
//    public Piece getPiece(){
//        return piece;
//    }
//    
//    public static void kill(Piece piece){
//        piece = null;
//    }
//}