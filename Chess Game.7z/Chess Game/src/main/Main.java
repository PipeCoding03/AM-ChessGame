package main;

import java.awt.Cursor;
import pieces.Piece;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import pieces.Empty;
import utils.PositionConvertor;

public class Main extends JPanel {
    public static JFrame window = new JFrame("AFMV's CHESS GAME");
    public static final int SQUARE_SIDE = 80;
    private static final int WINDOW_SIDE = SQUARE_SIDE * 8;
    public static ImageIcon blueSignal = new ImageIcon(new ImageIcon("resources/img/signals/blue.png").getImage().getScaledInstance(Main.SQUARE_SIDE, Main.SQUARE_SIDE, Image.SCALE_SMOOTH));
    public static ImageIcon checkSignal = new ImageIcon(new ImageIcon("resources/img/signals/check.png").getImage().getScaledInstance(Main.SQUARE_SIDE, Main.SQUARE_SIDE, Image.SCALE_SMOOTH));
    public static ImageIcon greenSignal = new ImageIcon(new ImageIcon("resources/img/signals/green.png").getImage().getScaledInstance(Main.SQUARE_SIDE, Main.SQUARE_SIDE, Image.SCALE_SMOOTH));
    public static ImageIcon redSignal = new ImageIcon(new ImageIcon("resources/img/signals/red.png").getImage().getScaledInstance(Main.SQUARE_SIDE, Main.SQUARE_SIDE, Image.SCALE_SMOOTH));
    public static ArrayList<Piece> pieces = new ArrayList<>();
    public static Piece empty = new Empty();
    public static Piece selectedPiece = empty;
    public static boolean whiteCheck = false;
    public static boolean blackCheck = false;
    public static ArrayList<String> dominatedSquaresByWhite = new ArrayList<>();
    public static ArrayList<String> defendedSquaresByWhite = new ArrayList<>();
    public static String blackKingPosition = "e8";
    public static String whiteKingPosition = "e1";
    
    public static void main(String[] args){
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setSize(WINDOW_SIDE, WINDOW_SIDE);
        window.setLocationRelativeTo(null);
        window.getContentPane().add(new Main());
        window.setUndecorated(true);
        window.setVisible(true);
    }
    
    @Override
    public void paint(Graphics g){
        g.drawImage(new ImageIcon(new ImageIcon("resources/img/chess_board.png").getImage().getScaledInstance(WINDOW_SIDE, WINDOW_SIDE, Image.SCALE_SMOOTH)).getImage(), 0, 0, this);
        
//        selectedPiece.getDefendedSquares().clear();
        
        if (whiteCheck){
            Piece piece = pieces.get(Piece.getPieceIndex("white", "king"));
            Point pos = piece.getPosition();
            
            g.drawImage(checkSignal.getImage(), pos.x, pos.y, this);
        }
        if (blackCheck){
            Piece piece = pieces.get(Piece.getPieceIndex("black", "king"));
            Point pos = piece.getPosition();
            
            g.drawImage(checkSignal.getImage(), pos.x, pos.y, this);
        }
        
        if (selectedPiece != empty){
            Piece.highlightSelectedPiece(g);
        }
        selectedPiece.showLegalMoves(g);
        
        repaintBoard(g);
    }
    
    public void repaintBoard(Graphics g){
        pieces.forEach((piece) -> {
            repaintPiece(g, piece);
        });
        
        repaintPiece(g, selectedPiece);
        
        window.repaint();
    }
    
    private void repaintPiece(Graphics g, Piece piece){
        g.drawImage(piece.getPiece().getImage(), piece.getLocation().x, piece.getLocation().y, this);
    }
    
    public Main(){
        window.setIconImage(new ImageIcon("resources/img/chess.jpg").getImage());
        
        new GameSetup("");
        
        //Keys for the window
        window.addKeyListener(new KeyListener(){
            @Override
            public void keyPressed(KeyEvent e){
                switch (e.getKeyCode()){
                    case KeyEvent.VK_ESCAPE:
                        System.exit(0);
                        
                        break;
                    case KeyEvent.VK_C:
                        cleanBoard();
                        
                        break;
                    case KeyEvent.VK_N:
                        new GameSetup("starting_position");
                        
                        break;
                    case KeyEvent.VK_S:
                        new GameSetup("castle");
                        
                        break;
                    case KeyEvent.VK_T:
//                        Piece piece = pieces.get(Piece.getPieceIndex("black", "king"));
                        
                        pieces.get(2).outputLegalMoves();
                        pieces.get(3).outputLegalMoves();
                        
                        break;
                    case KeyEvent.VK_P:
                        for (int i = 0; i < pieces.size(); i++){
                            System.out.println((i + 1) + " = " + pieces.get(i).getColor() + " " + pieces.get(i).getName());
                        }
                        
                        System.out.println("Total pieces: " + pieces.size());
                        
                        break;
                }
            }

            @Override public void keyReleased(KeyEvent e){}
            @Override public void keyTyped(KeyEvent e){}
        });
        
        //Mouse motion listener for dragging the pieces
        window.addMouseMotionListener(new MouseMotionListener(){
            @Override
            public void mouseDragged(MouseEvent e){
                int limit = WINDOW_SIDE;
                int halfSquare = SQUARE_SIDE / 2;
                
                if ((e.getX() >= 0) && (e.getX() <= limit)){
                    if ((e.getY() >= 0) && (e.getY() <= limit)){
                        selectedPiece.setLocation(e.getX() - halfSquare, e.getY() - halfSquare);
                    } else {
                        if (e.getY() < 0){
                            selectedPiece.setLocation(e.getX() - halfSquare, -halfSquare);
                        } else {
                            selectedPiece.setLocation(e.getX() - halfSquare, limit - halfSquare);
                        }
                    }
                } else if ((e.getY() >= 0) && (e.getY() <= limit)){
                    if (e.getX() < 0){
                        selectedPiece.setLocation(-halfSquare, e.getY() - halfSquare);
                    } else {
                        selectedPiece.setLocation(limit - halfSquare, e.getY() - halfSquare);
                    }
                } else {
                    if (e.getX() < 0){
                        if (e.getY() < 0){
                            selectedPiece.setLocation(-halfSquare, -halfSquare);
                        } else {
                            selectedPiece.setLocation(-halfSquare, limit - halfSquare);
                        }
                    } else {
                        if (e.getY() < 0){
                            selectedPiece.setLocation(limit - halfSquare, -halfSquare);
                        } else {
                            selectedPiece.setLocation(limit - halfSquare, limit - halfSquare);
                        }
                    }
                }
            }

            @Override
            public void mouseMoved(MouseEvent e){
                Point mousePosition = new Point((e.getX() / SQUARE_SIDE) * SQUARE_SIDE, (e.getY() / SQUARE_SIDE) * SQUARE_SIDE);
                
                if (!getHoveredPiece(mousePosition).isEmpty()){
                    setCursor(new Cursor(Cursor.HAND_CURSOR));
                } else {
                    setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }
            }
        });
        
        //Mouse listener for the pieces
        window.addMouseListener(new MouseListener(){
            @Override
            public void mousePressed(MouseEvent e){
                Point mousePosition = new Point((e.getX() / SQUARE_SIDE) * SQUARE_SIDE, (e.getY() / SQUARE_SIDE) * SQUARE_SIDE );
                
                if (selectedPiece == empty){
                    for (Piece piece : pieces){
                        if ((piece.getPosition().x == mousePosition.x) && (piece.getPosition().y == mousePosition.y)){
                            selectedPiece = piece;
                            selectedPiece.setLocation(e.getX() - (SQUARE_SIDE / 2), e.getY() - (SQUARE_SIDE / 2));

                            break;
                        }
                    }
                }
                
                if (!selectedPiece.getName().equals("empty")){
                    selectedPiece.outputLegalMoves();
                }
            }

            @Override
            public void mouseReleased(MouseEvent e){
                Point mousePosition = new Point((e.getX() / SQUARE_SIDE) * SQUARE_SIDE, (e.getY() / SQUARE_SIDE) * SQUARE_SIDE);
                
                /*
                    With this, I verify the position of the cursor:
                    + If it's inside the board, I just drop the selected piece there.
                    + If it's outside the board, I drop the piece where it was selected from.
                */
                if ((e.getX() >= 0) && (e.getX() <= WINDOW_SIDE) && (e.getY() >= 0) && (e.getY() <= WINDOW_SIDE)){
                    if (getHoveredPiece(mousePosition).isEmpty()){
                        if (selectedPiece.is("king")){
                            if (selectedPiece.isWhite()){
                                selectedPiece.setLocation(mousePosition.x, mousePosition.y);
                                selectedPiece.setPosition(selectedPiece.getLocation());
                                
                                if (mousePosition.equals(new Point(2 * SQUARE_SIDE, 7 * SQUARE_SIDE))){
                                    for (int i = 0; i < pieces.size() ; i++){
                                        if (pieces.get(i).getDescription().equals("white_rook")){
                                            pieces.get(i).setLocation(mousePosition.x + SQUARE_SIDE, mousePosition.y);
                                            pieces.get(i).setPosition(pieces.get(i).getLocation());

                                            break;
                                        }
                                    }
                                } else if (mousePosition.equals(new Point(6 * SQUARE_SIDE, 7 * SQUARE_SIDE))){
                                    for (int i = pieces.size() - 1; i >= 0 ; i++){
                                        if (pieces.get(i).getDescription().equals("white_rook")){
                                            pieces.get(i).setLocation(mousePosition.x - SQUARE_SIDE, mousePosition.y);
                                            pieces.get(i).setPosition(pieces.get(i).getLocation());

                                            break;
                                        }
                                    }
                                } else {
                                    selectedPiece.resetPosition();
                                }
                                selectedPiece.wasMoved();
                            } else {
                                selectedPiece.setLocation(mousePosition.x, mousePosition.y);
                                selectedPiece.setPosition(selectedPiece.getLocation());
                                
                                if (mousePosition.equals(new Point(2 * SQUARE_SIDE, 0 * SQUARE_SIDE))){
                                    for (int i = 0; i < pieces.size() ; i++){
                                        if (pieces.get(i).getDescription().equals("black_rook")){
                                            pieces.get(i).setLocation(mousePosition.x + SQUARE_SIDE, mousePosition.y);
                                            pieces.get(i).setPosition(pieces.get(i).getLocation());

                                            break;
                                        }
                                    }
                                } else if (mousePosition.equals(new Point(6 * SQUARE_SIDE, 0 * SQUARE_SIDE))){
                                    for (int i = pieces.size() - 1; i >= 0 ; i--){
                                        if (pieces.get(i).getDescription().equals("black_rook")){
                                            pieces.get(i).setLocation(mousePosition.x - SQUARE_SIDE, mousePosition.y);
                                            pieces.get(i).setPosition(pieces.get(i).getLocation());

                                            break;
                                        }
                                    }
                                } else {
                                    selectedPiece.resetPosition();
                                }
                                selectedPiece.wasMoved();
                            }
                        } else {
                            selectedPiece.setLocation(mousePosition.x, mousePosition.y);
                            selectedPiece.setPosition(selectedPiece.getLocation());
                            selectedPiece.wasMoved();
                        }
                    } else {
                        selectedPiece.resetPosition();
                    }
                } else {
                    selectedPiece.resetPosition();
                }
                
                emptyHand();
                
                verifyChecks("white");
                verifyChecks("black");
            }
            
            @Override public void mouseClicked(MouseEvent e){}
            @Override public void mouseEntered(MouseEvent e){}
            @Override public void mouseExited(MouseEvent e){}
        });
    }
    
    private void verifyChecks(String color){
        Piece piece = pieces.get(Piece.getPieceIndex(color, "king"));
        
        if (color.equals("white")){
            if (Piece.findLegalMovesForBlack().contains(PositionConvertor.fromIndexToNotation(piece.getIndex()))){
                whiteCheck = true;
            } else {
                whiteCheck = false;
            }
        } else {
            if (Piece.findLegalMovesForWhite().contains(PositionConvertor.fromIndexToNotation(piece.getIndex()))){
                blackCheck = true;
            } else {
                blackCheck = false;
            }
        }
    }
    
    public static Piece getPiece(int x, int y){
        Piece pieceHere = empty;
        
        for (Piece piece : pieces){
            if (piece.getPosition().x == x){
                if (piece.getPosition().y == y){
                    pieceHere = piece;

                    break;
                }
            }
        }
        
        return pieceHere;
    }
    
    public static Piece getPiece(String square){
        int x = PositionConvertor.fromNotationToCoords(square, "x");
        int y = PositionConvertor.fromNotationToCoords(square, "y");
        
        return getPiece(x * SQUARE_SIDE, y * SQUARE_SIDE);
    }
    
    public static Piece getHoveredPiece(Point mousePosition){
        Piece pieceHere = empty;
        
        for (Piece piece : pieces){
            if (piece.getPosition().x == mousePosition.x){
                if (piece.getPosition().y == mousePosition.y){
                    pieceHere = piece;

                    break;
                }
            }
        }
        
        return pieceHere;
    }
    
    private void emptyHand(){
        selectedPiece = empty;
    }
    
    protected static void cleanBoard(){
        pieces.removeAll(pieces);
    }
}