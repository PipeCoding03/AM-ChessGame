////package main;
////
////public class Evaluate {
////    private static final int pawnValue = 100;
////    private static final int knightValue = 300;
////    private static final int bishopValue = 300;
////    private static final int rookValue = 500;
////    private static final int queenValue = 900;
////    
////    public static int evaluate(){ aún está como comentarios, pues aún no la termino <3
////        int whiteEvaluation = 0;
////        int blackEvaluation = 0;
////        
////        return whiteEvaluation - blackEvaluation;
////    }
////    
////    public static int countMaterial(String color){
////        int material = 0;
////        int pawnCount = 0;
////        int knightCount = 0;
////        int bishopCount = 0;
////        int rookCount = 0;
////        int queenCount = 0;
////        
////        for (int i = 0; i < 64; i++){
////            if (Board.squares[i].getPiece().getColor().equals(color)){
////                switch (Board.squares[i].getPiece().getPieceName()){
////                    case "pawn":
////                        pawnCount++;
////                        
////                        break;
////                    case "knight":
////                        knightCount++;
////                        
////                        break;
////                    case "bishop":
////                        bishopCount++;
////                        
////                        break;
////                    case "rook":
////                        rookCount++;
////                        
////                        break;
////                    case "queen":
////                        queenCount++;
////                        
////                        break;
////                }
////            }
////        }
////        
////        material += pawnCount * pawnValue;
////        material += knightCount * knightValue;
////        material += bishopCount * bishopValue;
////        material += rookCount * rookValue;
////        material += queenCount * queenValue;
////        
////        return material;
////    }
////}