package main;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Board extends JPanel {
    @Override
    public void paint(Graphics g){
        g.drawImage(new ImageIcon("resources/img/chess_board.png").getImage(), 0, 0, this);
    }
}