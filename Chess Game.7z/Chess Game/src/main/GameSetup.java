package main;

import pieces.*;
import utils.Notation;

public class GameSetup {
    private static String color = "none";
    private static String name = "empty";
    private static boolean skipFile = false;
    private static int index;
    public static int x, y;
    
    public GameSetup(String code){
        Main.whiteCheck = false;
        Main.blackCheck = false;
        index = 0;
        x = 0;
        y = 0;
        
        switch (code){
            case "starting_position":
                loadFEN("rnbqkbnr/pppppppp/////PPPPPPPP/RNBQKBNR");
                
                break;
            case "test":
                loadFEN("rnbqkbnr///////RNBQKBNR");
                
                break;
            case "castle":
                loadFEN("n3k2r/pppppppp/////PPPPPPPP/N3K2R");
//                loadFEN("rnbqkbnr/pppppppp/////PPPPPPPP/R3K2R");
                
                break;
            default:
                loadFEN("rnbqkbnr/pppppppp/////PPPPPPPP/RNBQKBNR");
                
                break;
        }
        
//        loadFEN("r2Q2R2q/2N4n//4p");
//        loadFEN("rn2kbnr/ppp2ppp/8/4P3/2p3b1/4PP2/PP4PP/RNBK1BNR");
    }
    
    public static void loadFEN(String fen){
        Main.cleanBoard();
        
        System.out.println("Loading FEN...");
        
        for (int i = 0; i < fen.length(); i++){
            //Define piece
            switch (fen.toUpperCase().charAt(i)){
                case 'K':
                    name = "king";
                    skipFile = false;

                    break;
                case 'Q':
                    name = "queen";
                    skipFile = false;

                    break;
                case 'R':
                    name = "rook";
                    skipFile = false;

                    break;
                case 'N':
                    name = "knight";
                    skipFile = false;

                    break;
                case 'B':
                    name = "bishop";
                    skipFile = false;

                    break;
                case 'P':
                    name = "pawn";
                    skipFile = false;

                    break;
                case '/':
                    skipFile = true;
                    x = 0;
                    y += Main.SQUARE_SIDE;
                    
                    break;
                default:
                    try {
                        int squaresToSkip = Integer.parseInt(String.valueOf(fen.charAt(i)));
                        
                        x += (squaresToSkip - 1) * Main.SQUARE_SIDE;
                        
                        skipFile = false;
                    } catch (NumberFormatException e){
                        System.err.print("Invalid character at index: " + i);
                    }
                    
                    break;
            }
            
            //Define color
            if (Notation.isUpperCase(String.valueOf(fen.charAt(i)))){
                color = "white";
            } else if (!Notation.isUpperCase(String.valueOf(fen.charAt(i)))) {
                color = "black";
            }
            
            //Set the piece on its location
            if (!skipFile){
                Piece piece = new Empty();
                
                switch (name){
                    case "pawn":
                        piece = new Pawn(color, x, y);
                        
                        break;
                    case "knight":
                        piece = new Knight(color, x, y);
                        
                        break;
                    case "bishop":
                        piece = new Bishop(color, x, y);
                        
                        break;
                    case "rook":
                        piece = new Rook(color, x, y);
                        
                        break;
                    case "queen":
                        piece = new Queen(color, x, y);
                        
                        break;
                    case "king":
                        piece = new King(color, x, y);
                        
                        break;
                }
                
                if (!piece.getName().equals("empty")){
//                    This is for finding hw many pieces like this are
//                    piecesLikeThis = 0;
//                    
//                    for (Piece p: Main.pieces){
//                        if (p.getName().equals("pawn")){
//                            piecesLikeThis++;
//                        }
//                    }

//                    for (Piece p: Main.pieces){
//                        if ((p.getCoordinates().x == x / 80) && (p.getCoordinates().y == y / 80)){
//                            if (p.getName().equals("empty")){
//                                int x = Main.pieces.indexOf(p);
//                                Main.pieces.remove(x);
//                                break;
//                            }
//                        }
//                    }

//                    Main.pieces.remove(0);
                    Main.pieces.add(piece);
                }

                x += Main.SQUARE_SIDE;
                
                index++;
                
                name = "empty";
            }
        }
        
        System.out.println("Done!");
    }
}