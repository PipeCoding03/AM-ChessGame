package pieces;

public class Queen extends Piece {
    public Queen(String color, int xPos, int yPos){
        super(color, "queen", xPos, yPos);
    }

    @Override
    public void findLegalMoves(){
        this.getDominatedSquares().clear();
        this.getDefendedSquares().clear();
        
        movesInThisDirection(0, -1, 8); //Up
        movesInThisDirection(1, 0, 8); //Right
        movesInThisDirection(0, 1, 8); //Down
        movesInThisDirection(-1, 0, 8); //Left
        movesInThisDirection(1, -1, 8); //Up right
        movesInThisDirection(1, 1, 8); //Down right
        movesInThisDirection(-1, 1, 8); //Down left
        movesInThisDirection(-1, -1, 8); //Up left
    }
}