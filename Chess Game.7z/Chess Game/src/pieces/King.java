package pieces;

import java.awt.Graphics;
import static main.Main.SQUARE_SIDE;
import static main.Main.blueSignal;
import static main.Main.pieces;
import static main.Main.window;
import utils.PositionConvertor;

public class King extends Piece {
    public King(String color, int xPos, int yPos){
        super(color, "king", xPos, yPos);
    }

    @Override
    public void findLegalMoves(){
        this.getDominatedSquares().clear();
        this.getDefendedSquares().clear();
        
        movesInThisDirection(0, -1, 1); //Up
        movesInThisDirection(1, 0, 1); //Right
        movesInThisDirection(0, 1, 1); //Down
        movesInThisDirection(-1, 0, 1); //Left
        movesInThisDirection(1, -1, 1); //Up right
        movesInThisDirection(1, 1, 1); //Down right
        movesInThisDirection(-1, 1, 1); //Down left
        movesInThisDirection(-1, -1, 1); //Up left
        checkShortCastle();
        checkLongCastle();
    }
    
    private void checkShortCastle(){
        if (isWhite()){
            Piece h1Rook = new Empty();
            int x = getCoordinates().x * SQUARE_SIDE;
            int y = getCoordinates().y * SQUARE_SIDE;

            for (int i = pieces.size() - 1; i >= 0; i--){
                if (pieces.get(i).getDescription().equals("white_rook")){
                    h1Rook = pieces.get(i);

                    break;
                }
            }
            
            if (h1Rook.getCoordinates().x == 7){
                if ((this.hasBeenMoved() == false) && (h1Rook.hasBeenMoved() == false)){
                    if ((main.Main.getPiece(x + SQUARE_SIDE, y).is("empty")) && (main.Main.getPiece(x + (SQUARE_SIDE * 2), y).is("empty"))){
                        if (!Piece.findLegalMovesForBlack().contains(PositionConvertor.fromCoordsToNotation(x / SQUARE_SIDE, y / SQUARE_SIDE))){
                            if (!(Piece.findLegalMovesForBlack().contains("f1")) && !(Piece.findLegalMovesForBlack().contains("g1"))){
                                if (!dominatedSquares.contains(PositionConvertor.fromCoordsToNotation((x / SQUARE_SIDE) + 2, y / SQUARE_SIDE))){
                                    dominatedSquares.add(PositionConvertor.fromCoordsToNotation((x / SQUARE_SIDE) + 2, y / SQUARE_SIDE));
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Piece h8Rook = new Empty();
            int x = getCoordinates().x * SQUARE_SIDE;
            int y = getCoordinates().y * SQUARE_SIDE;

            for (int i = pieces.size() - 1; i >= 0 ; i--){
                if (pieces.get(i).getDescription().equals("black_rook")){
                    h8Rook = pieces.get(i);

                    break;
                }
            }
            
            if (h8Rook.getCoordinates().x == 7){
                if (h8Rook.is("rook")){
                    if ((this.hasBeenMoved() == false) && (h8Rook.hasBeenMoved() == false)){
                        if ((main.Main.getPiece(x + SQUARE_SIDE, y).is("empty")) && (main.Main.getPiece(x + (SQUARE_SIDE * 2), y).is("empty"))){
                            if (!Piece.findLegalMovesForWhite().contains(PositionConvertor.fromCoordsToNotation(x / SQUARE_SIDE, y / SQUARE_SIDE))){
                                if (!(Piece.findLegalMovesForWhite().contains("f8")) && !(Piece.findLegalMovesForWhite().contains("g8"))){
                                    if (!dominatedSquares.contains(PositionConvertor.fromCoordsToNotation((x / SQUARE_SIDE) + 2, y / SQUARE_SIDE))){
                                        dominatedSquares.add(PositionConvertor.fromCoordsToNotation((x / SQUARE_SIDE) + 2, y / SQUARE_SIDE));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    private void checkLongCastle(){
        if (isWhite()){
            Piece a1Rook = new Empty();
            int x = getCoordinates().x * SQUARE_SIDE;
            int y = getCoordinates().y * SQUARE_SIDE;

            for (int i = 0; i < pieces.size(); i++){
                if (pieces.get(i).getDescription().equals("white_rook")){
                    a1Rook = pieces.get(i);

                    break;
                }
            }
            
            if (a1Rook.getCoordinates().x == 0){
                if ((this.hasBeenMoved() == false) && (a1Rook.hasBeenMoved() == false)){
                    if ((main.Main.getPiece(x - SQUARE_SIDE, y).is("empty")) && (main.Main.getPiece(x - (SQUARE_SIDE * 2), y).is("empty"))){
                        if (main.Main.getPiece(x - (SQUARE_SIDE * 3), y).is("empty")){
                            if (!Piece.findLegalMovesForBlack().contains(PositionConvertor.fromCoordsToNotation(x / SQUARE_SIDE, y / SQUARE_SIDE))){
                                if (!(Piece.findLegalMovesForBlack().contains("d1")) && !(Piece.findLegalMovesForBlack().contains("c1"))){
                                    if (!dominatedSquares.contains(PositionConvertor.fromCoordsToNotation((x / SQUARE_SIDE) - 2, y / SQUARE_SIDE))){
                                        dominatedSquares.add(PositionConvertor.fromCoordsToNotation((x / SQUARE_SIDE) - 2, y / SQUARE_SIDE));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Piece a8Rook = new Empty();
            int x = getCoordinates().x * SQUARE_SIDE;
            int y = getCoordinates().y * SQUARE_SIDE;

            for (int i = 0; i < pieces.size(); i++){
                if (pieces.get(i).getDescription().equals("black_rook")){
                    a8Rook = pieces.get(i);

                    break;
                }
            }

            if (a8Rook.getCoordinates().x == 0){
                if ((this.hasBeenMoved() == false) && (a8Rook.hasBeenMoved() == false)){
                    if ((main.Main.getPiece(x - SQUARE_SIDE, y).is("empty")) && (main.Main.getPiece(x - (SQUARE_SIDE * 2), y).is("empty"))){
                        if (main.Main.getPiece(x - (SQUARE_SIDE * 3), y).is("empty")){
                            if (!Piece.findLegalMovesForWhite().contains(PositionConvertor.fromCoordsToNotation(x / SQUARE_SIDE, y / SQUARE_SIDE))){
                                if (!(Piece.findLegalMovesForWhite().contains("d8")) && !(Piece.findLegalMovesForWhite().contains("c8"))){
                                    if (!dominatedSquares.contains(PositionConvertor.fromCoordsToNotation((x / SQUARE_SIDE) - 2, y / SQUARE_SIDE))){
                                        dominatedSquares.add(PositionConvertor.fromCoordsToNotation((x / SQUARE_SIDE) - 2, y / SQUARE_SIDE));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    private void showShortCastle(Graphics g){
        int x = getCoordinates().x * SQUARE_SIDE;
        int y = getCoordinates().y * SQUARE_SIDE;
        String kingPosition = "";
        
        if (isWhite()){
            kingPosition= "e1";
        } else {
            kingPosition = "e8";
        }
        
        if ((x == PositionConvertor.fromNotationToCoords(kingPosition, "x") * SQUARE_SIDE)){
            if ((y == PositionConvertor.fromNotationToCoords(kingPosition, "y") * SQUARE_SIDE)){
                if (dominatedSquares.contains(PositionConvertor.fromCoordsToNotation((x / SQUARE_SIDE) + 2, y / SQUARE_SIDE))){
                    g.drawImage(blueSignal.getImage(), x + (SQUARE_SIDE * 2), y, window);
                }
            }
        }
    }
    
    private void showLongCastle(Graphics g){
        int x = getCoordinates().x * SQUARE_SIDE;
        int y = getCoordinates().y * SQUARE_SIDE;
        String kingPosition = "";
        
        if (isWhite()){
            kingPosition= "e1";
        } else {
            kingPosition = "e8";
        }
        
        if ((x == PositionConvertor.fromNotationToCoords(kingPosition, "x") * SQUARE_SIDE)){
            if ((y == PositionConvertor.fromNotationToCoords(kingPosition, "y") * SQUARE_SIDE)){
                if (dominatedSquares.contains(PositionConvertor.fromCoordsToNotation((x / SQUARE_SIDE) - 2, y / SQUARE_SIDE))){
                    g.drawImage(blueSignal.getImage(), x - (SQUARE_SIDE * 2), y, window);
                }
            }
        }
    }
}