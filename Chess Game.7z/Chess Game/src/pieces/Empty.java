package pieces;

import java.awt.Graphics;

public class Empty extends Piece {
    public Empty(){
        super();
    }
    
    public Empty(int xPos, int yPos){
        super(xPos, yPos);
    }

    @Override
    public void showLegalMoves(Graphics g){}

    @Override
    public void findLegalMoves(){}
}