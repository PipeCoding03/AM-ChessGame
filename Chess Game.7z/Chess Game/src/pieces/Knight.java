package pieces;

import main.Main;
import static main.Main.SQUARE_SIDE;
import utils.PositionConvertor;

public class Knight extends Piece {
    public Knight(String color, int xPos, int yPos){
        super(color, "knight", xPos, yPos);
    }

    @Override
    public void findLegalMoves(){
        this.getDominatedSquares().clear();
        this.getDefendedSquares().clear();
        
        movesForTheKnight(2, -1);
        movesForTheKnight(2, 1);
        movesForTheKnight(-2, -1);
        movesForTheKnight(-2, 1);
        movesForTheKnight(1, 2);
        movesForTheKnight(1, -2);
        movesForTheKnight(-1, 2);
        movesForTheKnight(-1, -2);
    }
    
    public void movesForTheKnight(int xOffset, int yOffset){
        int x = getCoordinates().x;
        int y = getCoordinates().y;
        String colorOfThePieceHere = "";
        
        if ((x + xOffset >= 0) && (x + xOffset <= 7) && (y + yOffset >= 0) && (y + yOffset <= 7)){
            colorOfThePieceHere = Main.getPiece((x + xOffset) * SQUARE_SIDE, (y + yOffset) * SQUARE_SIDE).getColor();
            
            if (Main.getPiece((x + xOffset) * SQUARE_SIDE, (y + yOffset) * SQUARE_SIDE).isEmpty()){
                dominatedSquares.add(PositionConvertor.fromCoordsToNotation(x + xOffset, y + yOffset));
            }
            
            if (!colorOfThePieceHere.equals("none")){
                if (colorOfThePieceHere.equals(getColor())){
                    defendedSquares.add(PositionConvertor.fromCoordsToNotation(x + xOffset, y + yOffset));
                } else {
                    dominatedSquares.add(PositionConvertor.fromCoordsToNotation(x + xOffset, y + yOffset));
                }
            }
        }
    }
}