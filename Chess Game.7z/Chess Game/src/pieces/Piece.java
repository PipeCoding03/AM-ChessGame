package pieces;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import main.Main;
import static main.Main.SQUARE_SIDE;
import static main.Main.blueSignal;
import static main.Main.greenSignal;
import static main.Main.pieces;
import static main.Main.redSignal;
import static main.Main.selectedPiece;
import static main.Main.window;
import utils.PositionConvertor;

public abstract class Piece {
    private String color = "";
    private String name = "";
    private ImageIcon piece = new ImageIcon("");
    private Point location; //Logical position
    private Point position; //Visual position
    private Point coordinates;
    private int index;
    private boolean hasBeenMoved = false;
    public ArrayList<String> dominatedSquares = new ArrayList<>();
    public ArrayList<String> defendedSquares = new ArrayList<>();
    
    public Piece(String color, String name, int xPos, int yPos){
        this.color = color;
        this.name = name;
        this.piece = new ImageIcon(new ImageIcon("resources/img/pieces/"+color+"/"+name+".png").getImage().getScaledInstance(Main.SQUARE_SIDE, Main.SQUARE_SIDE, Image.SCALE_SMOOTH));
        this.location = new Point(xPos, yPos);
        this.position = location;
        this.coordinates = new Point(position.x / Main.SQUARE_SIDE, position.y / Main.SQUARE_SIDE);
        this.index = PositionConvertor.fromCoordsToIndex(this.position.x, this.position.y);
    }
    
    public Piece(){
        this.name = "empty";
        this.color = "none";
        this.location = new Point(0, 0);
        this.position = location;
    }
    
    public Piece(int xPos, int yPos){
        this.name = "empty";
        this.color = "none";
        this.location = new Point(xPos, yPos);
        this.position = location;
        this.coordinates = new Point(position.x, position.y);
    }
    
    public static void highlightSelectedPiece(Graphics g){
        g.drawImage(greenSignal.getImage(), selectedPiece.getCoordinates().x * SQUARE_SIDE, selectedPiece.getCoordinates().y * SQUARE_SIDE, window);
    }
    
    public void movesInThisDirection(int xOffset, int yOffset, int limit){
        int x = getCoordinates().x + xOffset;
        int y = getCoordinates().y + yOffset;
        
        for (int i = 0; i < limit; i += 1){
            if ((x < 8) && (y < 8) && (x >= 0) && (y >= 0)){
                String colorOfThePieceHere = Main.getPiece(x * SQUARE_SIDE, y * SQUARE_SIDE).getColor();
                
                if (getDescription().equals("white_king")){
                    if (!Piece.findLegalMovesForBlack().contains(PositionConvertor.fromCoordsToNotation(x, y))){
                        if (colorOfThePieceHere.equals("none")){
                            dominatedSquares.add(PositionConvertor.fromCoordsToNotation(x, y));
                        } else {
                            if (colorOfThePieceHere.equals(getColor())){
                                defendedSquares.add(PositionConvertor.fromCoordsToNotation(x, y));
                            } else {
                                dominatedSquares.add(PositionConvertor.fromCoordsToNotation(x, y));
                            }
                        }
                    }
                } else if (getDescription().equals("black_king")){
                    if (!Piece.findLegalMovesForWhite().contains(PositionConvertor.fromCoordsToNotation(x, y))){
                        if (colorOfThePieceHere.equals(getColor())){
                            defendedSquares.add(PositionConvertor.fromCoordsToNotation(x, y));
                        } else if (colorOfThePieceHere.equals("white")){
                            dominatedSquares.add(PositionConvertor.fromCoordsToNotation(x, y));
                        } else {
                            dominatedSquares.add(PositionConvertor.fromCoordsToNotation(x, y));
                        }
                    }
                } else {
                    if (!colorOfThePieceHere.equals("none")){
                        if (!colorOfThePieceHere.equals(color)){
                            if (!dominatedSquares.contains(PositionConvertor.fromCoordsToNotation(x, y))){
                                dominatedSquares.add(PositionConvertor.fromCoordsToNotation(x, y));
                            }
                        } else {
                            if (!defendedSquares.contains(PositionConvertor.fromCoordsToNotation(x, y))){
                                defendedSquares.add(PositionConvertor.fromCoordsToNotation(x, y));
                            }
                        }
                    } else {
                        if (!dominatedSquares.contains(PositionConvertor.fromCoordsToNotation(x, y))){
                            dominatedSquares.add(PositionConvertor.fromCoordsToNotation(x, y));
                        }

                        x += xOffset;
                        y += yOffset;
                    }
                }
            }
        }
    }
    
    public void kill(){
        Main.pieces.remove(this);
    }
    
    public abstract void findLegalMoves();
    
    public void showLegalMoves(Graphics g){
        int x = 0;
        int y = 0;

        for (String move : dominatedSquares){
            x = PositionConvertor.fromNotationToCoords(move, "x") * SQUARE_SIDE;
            y = PositionConvertor.fromNotationToCoords(move, "y") * SQUARE_SIDE;
            
            if (main.Main.getPiece(move).isEmpty()){
                g.drawImage(blueSignal.getImage(), x, y, window);
            } else {
                if (!main.Main.getPiece(move).getColor().equals(getColor())){
                    g.drawImage(redSignal.getImage(), x, y, window);
                }
            }
        }
        
        for (String move : defendedSquares){
            x = PositionConvertor.fromNotationToCoords(move, "x") * SQUARE_SIDE;
            y = PositionConvertor.fromNotationToCoords(move, "y") * SQUARE_SIDE;
            
            if (!main.Main.getPiece(move).isEmpty()){
                if (!main.Main.getPiece(move).getColor().equals(getColor())){
                    g.drawImage(redSignal.getImage(), x, y, window);
                }
            }
        }
    }
    
    public static ArrayList<String> findLegalMovesForWhite(){
        ArrayList<String> legalMovesForWhite = new ArrayList<>();
        
        for (Piece piece : pieces){
            if (piece.isWhite()){
                if (!piece.is("king")){
                    if (piece.is("pawn")){
                        piece.findLegalMoves();
                        ArrayList<String> legalMovesForThisPiece = piece.getDefendedSquares();
                        
                        for (String move : legalMovesForThisPiece){
                            if (!legalMovesForWhite.contains(move)){
                                legalMovesForWhite.add(move);
                            }
                        }
                    } else {
                        piece.findLegalMoves();
                        ArrayList<String> legalMovesForThisPiece = piece.getDominatedSquares();

                        for (String move : legalMovesForThisPiece){
                            if (!legalMovesForWhite.contains(move)){
                                legalMovesForWhite.add(move);
                            }
                        }
                    }
                }
            }
        }
        
        return legalMovesForWhite;
    }
    
    public static ArrayList<String> findLegalMovesForBlack(){
        ArrayList<String> legalMovesForBlack = new ArrayList<>();
        
        for (Piece piece : pieces){
            if (piece.isBlack()){
                if (!piece.is("king")){
                    if (piece.is("pawn")){
                        piece.findLegalMoves();
                        ArrayList<String> defendedSquaresByThisPiece = piece.getDefendedSquares();
                        
                        for (String move : defendedSquaresByThisPiece){
                            if (!legalMovesForBlack.contains(move)){
                                legalMovesForBlack.add(move);
                            }
                        }
                    } else {
                        piece.findLegalMoves();
                        ArrayList<String> legalMovesForThisPiece = piece.getDominatedSquares();

                        for (String move : legalMovesForThisPiece){
                            if (!legalMovesForBlack.contains(move)){
                                legalMovesForBlack.add(move);
                            }
                        }
                        
                        piece.findLegalMoves();
                        ArrayList<String> defendedSquaresByThisPiece = piece.getDominatedSquares();

                        for (String move : defendedSquaresByThisPiece){
                            if (!legalMovesForBlack.contains(move)){
                                legalMovesForBlack.add(move);
                            }
                        }
                    }
                }
            }
        }
        
        return legalMovesForBlack;
    }
    
    public void outputLegalMoves(){
        findLegalMoves();
        
        System.out.print("Controlled by '" + name + "': ");
        System.out.println(dominatedSquares + " = " + dominatedSquares.size());

        System.out.print("Defended by '" + name + "': ");
        System.out.println(defendedSquares + " = " + defendedSquares.size());
    }
    
    public static int getPieceIndex(String color, String name){
        for (int i = 0; i < pieces.size(); i++){
            if ((pieces.get(i).color.equals(color)) && (pieces.get(i).name.equals(name))){
                return i;
            }
        }
        return 0;
    }

    public ImageIcon getPiece(){
        return piece;
    }

    public Point getLocation(){
        return location;
    }

    public String getColor(){
        return color;
    }

    public String getName(){
        return name;
    }
    
    public String getDescription(){
        return color + "_" + name;
    }

    public int getIndex(){
        return index;
    }

    public Point getPosition(){
        return position;
    }

    public Point getCoordinates(){
        return coordinates;
    }

    public ArrayList<String> getDominatedSquares(){
        return dominatedSquares;
    }

    public ArrayList<String> getDefendedSquares(){
        return defendedSquares;
    }

    public void setLocation(int x, int y){
        this.location = new Point(x, y);
    }
    
    public void setLocation(Point location){
        this.location = location;
    }
    
    public void resetPosition(){
        setLocation(getPosition());
        setPosition(getLocation());
    }
    
    public void setCoordinates(int x, int y){
        this.coordinates = new Point(x, y);
    }

    public void setPosition(Point position){
        this.position = position;
        this.coordinates = new Point(position.x / Main.SQUARE_SIDE, position.y / Main.SQUARE_SIDE);
        this.index = PositionConvertor.fromCoordsToIndex(this.position.x, this.position.y);
    }

    public void setPiece(String piece){
        selectedPiece.kill();
    }
    
    public boolean isEmpty(){
        return name.equals("empty");
    }
    
    public boolean isWhite(){
        return color.equals("white");
    }
    
    public boolean isBlack(){
        return color.equals("black");
    }
    
    public boolean is(String name){
        return name.equals(this.name);
    }
    
    public boolean hasBeenMoved(){
        return hasBeenMoved;
    }
    
    public void wasMoved(){
        this.hasBeenMoved = true;
    }
}