package pieces;

import java.util.ArrayList;
import static main.Main.SQUARE_SIDE;
import utils.PositionConvertor;

public class Pawn extends Piece {
    public ArrayList<String> attackedSquares = new ArrayList<>();
    
    public Pawn(String color, int xPos, int yPos){
        super(color, "pawn", xPos, yPos);
    }

    @Override
    public void findLegalMoves(){
        this.getDominatedSquares().clear();
        this.getDefendedSquares().clear();
        
        int startingFile = 6;
        int x = getPosition().x;
        int y = getPosition().y;
        int xCoord = getCoordinates().x;
        int yCoord = getCoordinates().y;
//        int xOffset = -SQUARE_SIDE;
        int yOffset = -SQUARE_SIDE;
        int signsChanger = 1;
        
        if (this.isBlack()){
            startingFile = 1;
            yOffset *= -1;
            //Color
            signsChanger *= -1;
        }
        
        if (main.Main.getPiece(x, y + yOffset).isEmpty()){
            //Pin
            
            dominatedSquares.add(PositionConvertor.fromCoordsToNotation(xCoord, yCoord - (1 * signsChanger)));

            if ((yCoord == startingFile) && (main.Main.getPiece(x, y + (yOffset * (2 * signsChanger))).isEmpty())){
                dominatedSquares.add(PositionConvertor.fromCoordsToNotation(xCoord, yCoord - (2 * signsChanger)));
            }
        }
        
        if ((xCoord - 1 >= 0) && (xCoord - 1 <= 7) && (yCoord - (1 * signsChanger) >= 0) && (yCoord - (1 * signsChanger) <= 7)){
            defendedSquares.add(PositionConvertor.fromCoordsToNotation(xCoord - 1, yCoord - (1 * signsChanger)));
        }

        if ((xCoord + 1 >= 0) && (xCoord + 1 <= 7) && (yCoord - (1 * signsChanger) >= 0) && (yCoord - (1 * signsChanger) <= 7)){
            defendedSquares.add(PositionConvertor.fromCoordsToNotation(xCoord + 1, yCoord - (1 * signsChanger)));
        }
    }
}