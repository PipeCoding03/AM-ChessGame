package pieces;

public class Bishop extends Piece {
    public Bishop(String color, int xPos, int yPos){
        super(color, "bishop", xPos, yPos);
    }

    @Override
    public void findLegalMoves(){
        this.getDominatedSquares().clear();
        this.getDefendedSquares().clear();
        
        movesInThisDirection(1, -1, 8); //Up right
        movesInThisDirection(1, 1, 8); //Down right
        movesInThisDirection(-1, 1, 8); //Down left
        movesInThisDirection(-1, -1, 8); //Up left
    }
}