package pieces;

public class Rook extends Piece {
    public Rook(String color, int xPos, int yPos){
        super(color, "rook", xPos, yPos);
    }

    @Override
    public void findLegalMoves(){
        this.getDominatedSquares().clear();
        this.getDefendedSquares().clear();
        
        movesInThisDirection(0, -1, 8); //Up
        movesInThisDirection(1, 0, 8); //Right
        movesInThisDirection(0, 1, 8); //Down
        movesInThisDirection(-1, 0, 8); //Left
    }
}